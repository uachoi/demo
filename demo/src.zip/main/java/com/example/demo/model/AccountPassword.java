package com.example.demo.model;

public class AccountPassword {
    private String accountPassword;

    // Getters and Setters
    public String getAccountPassword() {
        return accountPassword;
    }

    public void setAccountPassword(String accountPassword) {
        this.accountPassword = accountPassword;
    }
}